#!/bin/bash

for fil in $*
do
	./filkontroll.sh 60 $fil & #Bruker filkontrollen til å sjekke flere filer med 60sek mellomrom
done
