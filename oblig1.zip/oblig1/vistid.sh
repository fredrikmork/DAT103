#!/bin/bash
read -p "Hva er hendelsen?" hendelse #Spør brukeren om hvilken hendelsen man vil få ut kjøretiden til
sjekker=$(grep -o $hendelse hendelse.logg | wc -l) #Hvor mange ganger hendelsen forekommer i loggen
kjoretid=0 #hva hver kjøretid er
total=0 #Hva total kjøretid for en gitt hendelse er
#Adderer kjøretiden for hver gang hendelsen forekommer i loggen.
for (( i=1; $i<=$sjekker;i++ )); do
	kjoretid=$(grep -m $i $hendelse hendelse.logg | cut -f2 -d$'\t' | awk '{ total += $1 } END { print total }')
done
#Printer ut totale kjøretiden for en hendelse
echo "Kjøretiden for $hendelse er: $kjoretid." #

