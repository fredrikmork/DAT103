#!/bin/bash
tidsintervall=$1
fil=$2
if [ ! -f $fil ]; then #Hvis filen ikke eksisterer så
	while true; do #Mens det er sant (Alltid sant når jeg skriver true)
		sleep $tidsintervall #sover i tidsintervallet slik at man kan gjøre en endring (Skjer ikke momentant)
		if [ -f $fil ]; then #Hvis filen nå eksisterer etter tidsintervallet så
			echo "Filen $fil er opprettet."
			exit 0 #Avslutter programmet slik at den ikke kjører evig og sjekker
		else  #Hvis filen ikke eksisterer etter tidsintervallet
			echo "Filen $fil eksisterer ikke, vennligst opptrett filen."
		fi
	done
else #Hvis filen eksisterer til å starte med
	Gammelfil=$(stat $fil -c%Y) #Status til filen til å starte med
	while [ -f $fil ]; do #Mens filen eksisterer.
		sleep $tidsintervall
		if [ ! -f $fil ]; then #Hvis filen nå ikke eksister så
			echo "Filen $fil har blitt slettet."
			exit 0
		else #Hvis den fortsatt eksisterer
			NyFil=$(stat $fil -c%Y) #Sjekker status til filen nå
			if [[ $Gammelfil != $NyFil ]]; then #Hvis gamlestatusen er forskjellig til den nye filen
				echo "Filen $fil har blitt endret."
				exit 0
			fi
		fi
	done
fi


