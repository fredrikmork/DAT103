#!/bin/bash
echo " Tast inn tall du vil summere, og trykk på Ctrl + D for å summere."

declare -i sum=0

while read num
	do
		sum+=$num
done

echo "Summen er: $sum"
